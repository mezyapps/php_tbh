<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>The Biryani House</title>

  <link rel = "icon" type = "image/png" href = "image/icon.png">
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body class="" style="color:white;background-color:#1ABC9C">

  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header text-center" style="color:white;background-color:#F6874F">
        <h5>Login Page</h5></div>
      <div class="card-body">
        <form method="post" action="">
          <div class="form-group">
            <div class="form-label-group">
              <input type="text" id="inputEmail" name="inputEmail" class="form-control" placeholder="User Name" required="required" autofocus="autofocus" style="color:#F6874F;border-color: #F6874F;">
              <label style="color:#F6874F" for="inputEmail">User Name</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required="required" style="color:#F6874F;border-color: #F6874F;">
              <label style="color:#F6874F" for="inputPassword">Password</label>
            </div>
          </div>
          <div class="form-group">
            <div class="checkbox">
              <label style="color:#F6874F">
                <input type="checkbox" value="remember-me" style="color:#F6874F">
                Remember Password
              </label>
            </div>
          </div>
          <button class="btn btn-block" style="background-color:#F6874F;color:white" name="login">Login</button>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="register.php" style="color:#F6874F">Register an Account</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>


<?php
session_start();
include_once 'config.php';
if(isset($_POST['login'])){
  $email=$_POST['inputEmail'];
  $password=$_POST['inputPassword'];
  $pass=base64_encode($password);
  $sql="select * from admins where email='".$email."' and password='".$pass."' limit 1";
  $result=mysqli_query($conn,$sql);
  if(mysqli_num_rows($result)==1){
   header("Location:http://tbh.mezyapps.com");
    $_SESSION["username"] = $email;
  }
  else
  {
    echo '<script type="text/javascript">';
    echo 'alert("Please enter valid username and password");';
    echo '</script>';

  }
}
?>