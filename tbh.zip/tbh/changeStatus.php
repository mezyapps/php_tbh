<?php
$id=$_GET['id'];
$status=$_GET['status']; 
if($status=="1")
{
  updateStatus($id,"0");	
}
else
{
updateStatus($id,"1");	
}

function updateStatus($id,$status)
{
	include_once 'config.php';
	$updquery="UPDATE `offers` SET `status`='".$status."' WHERE id='".$id."'";
	if ($conn->query($updquery) === TRUE) {
		echo '<script type="text/javascript">'; 
		echo 'alert("Offer updated successfully");'; 
    	header("Location: http://mezyapps.com/tbh/");
		echo '</script>';
	}
	else
	{
		echo '<script language="javascript">';
		echo 'alert("Somthing went wrong")';
        header("Location: http://mezyapps.com/tbh/");
		echo '</script>';

	}
}

?>