<?php 
include 'navigation.php';
include 'header.php'; 
include 'slidebar.php';
?>


  <div class="container" >
  	<div class="card card-register mx-auto mt-5">
      <div class="card-header text-center" style="color:white;background-color:#343a40">
        <h5><i>Add Offers</i></h5></div>
      <div class="card-body">
        <form action="" method="post" enctype="multipart/form-data">
          <div class="form-group">
                <div class="form-label-group">
                  <input type="text" id="inputTitle" class="form-control" placeholder="Title" required="required" autofocus="autofocus" name="inputTitle" style="color:#343a40;border-color: #343a40;">
                  <label for="inputTitle" style="color:#343a40;">Title</label>
                </div>
           
          	</div>
           <div class="form-group">
                <div class="form-label-group">
                  <input type="text" id="inputDescription" class="form-control" placeholder="Description" required="required" name="inputDescription" style="color:#343a40;border-color: #343a40;">
                  <label for="inputDescription" style="color:#343a40;">Description</label>
                </div>
           </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="date" id="inputDateFrom" class="form-control" placeholder="Valid Offer Up To" required="required" name="inputDateFrom" style="color:#343a40;border-color: #343a40;" value="<?php echo date("Y-m-d"); ?>" >
              <label for="inputDateFrom" style="color:#343a40;">Valid Offer Up To</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
                  <input type="file" id="inputFile" class="form-control" placeholder="Select photo" required="required" name="inputFile" style="color:#343a40;border-color: #343a40;">
                  <label for="inputFile" style="color:#343a40;">Select photo</label>
            </div>
          </div>
           <input type="submit" name="submit" value="submit" class="btn btn-block" style="background-color:#343a40;color:white"/>
        </form>
      </div>
    </div>
  </div>
 	</div>
 </div>
<?php include 'footer.php'?>  

<?php
include_once 'config.php';
date_default_timezone_set('Asia/Kolkata');
$c_date=date("Y-m-d H:i:s");
$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");

if (isset($_POST['submit'])) {

  $img=$_FILES["inputFile"]["name"];
  $type=$_FILES["inputFile"]["type"];
  $array = explode('.', $img);
  $fileName=$array[0];
  $fileExt=$array[1];
  $newfile=$fileName."_".time().".".$fileExt;

 $title=$_POST["inputTitle"];
 $description=$_POST["inputDescription"];
 $start_date=$_POST["inputDateFrom"];

 $newStartDate = date("Y-m-d", strtotime($start_date));
 $newEndDate = date("Y-m-d", strtotime($end_date));
 $status="1";

   if(array_key_exists($fileExt, $allowed)) 
   {

     $sql = "INSERT INTO offers(title,Description,start_date,image_path,status) VALUES('$title','$description', '$newStartDate','$newfile','$status')";

        if ($conn->query($sql) === TRUE) {
          move_uploaded_file($_FILES["inputFile"]["tmp_name"], "image/".$newfile);
          sendNotification($title,$description);
          echo '<script type="text/javascript">'; 
          echo 'alert("Offer Add Sucessfully");'; 
          echo '</script>';
      }
  }else
  {
      echo '<script type="text/javascript">'; 
      echo 'alert("Please select a valid file format");'; 
      echo '</script>';
  }
}

function sendNotification($title,$description)
{
    $server_key='AAAAXKGX5Cc:APA91bFx_ZCFZibVdzb4OSCMgVH6FDkHI2Rmr2-yT0YW2iSfmVa7Pb8qm1b5ezVKMPyxdn6TMp_GWazDN0nO45NUJvdcT9TQYn6i3yLi88QFYDhx_iUUBloRIeyPTgnNEwFmglQ_oj5j';
	$url='https://fcm.googleapis.com/fcm/send';

	$notification = array('title' =>$title , 'body' =>$description);
	$arrayToSend = array('to' =>'/topics/All_JMD', 'notification' => $notification,'priority'=>'high');
	
    $headers = array(
      'Authorization:key='.$server_key,
      'Content-Type: application/json'
    );
	
    $ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($arrayToSend));
	$result = curl_exec($ch);
	if ($result === FALSE) {
		die('Oops! FCM Send Error: ' . curl_error($ch));
	}
	curl_close($ch);
}

?>