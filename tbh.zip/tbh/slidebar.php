  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
    
      <li class="nav-item">
        <a class="nav-link" href="addOffer.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Add New Offers</span></a>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link" href="offer.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Offer</span></a>
      </li> -->
    </ul>
