
<?php
$servername="localhost";
$username="dbkenan";
$password="dbkenan@123";
$dbname="the_biryani_house";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


?>