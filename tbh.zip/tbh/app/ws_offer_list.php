<?php
include_once 'config.php';
$list=array();
$folder="image";
$status="1";
$current_date=date("Y-m-d");

$select="SELECT * FROM offers WHERE status='".$status."' AND start_date >='".$current_date."'";

$result = $conn->query($select);
   	  if($result->num_rows >0){
    		while($row = $result->fetch_assoc()) {
    				$list[]=$row;
    		}    
    		if (empty($list)) 
    		{
    		  $json_array= array('message' => "unsuccess",'code'=>"0",'folder_path'=>$folder,'offer_list'=>$list);
     		  echo json_encode($json_array);
    		}	
    		else
    		{	 
    		 $json_array= array('message' => "success",'code'=>"1",'folder_path'=>$folder,'offer_list'=>$list);
     		 echo json_encode($json_array); 
     		}
	 }else{
			 $json_array= array('message' => "unsuccess",'code'=>"0");
     		 echo json_encode($json_array); 
	 }	
$conn->close();
?>