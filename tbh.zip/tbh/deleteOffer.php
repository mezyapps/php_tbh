<?php
include_once 'config.php';
$id=$_GET['id'];
$path='image/'.$_GET['filepath'];
$sql = "DELETE FROM offers WHERE id='".$id."'";
if ($conn->query($sql) === TRUE) {
		echo '<script type="text/javascript">'; 
		echo 'alert("Delete Offer successfully");'; 
		echo '</script>';
		unlink($path);
		
}
else
{
		echo '<script language="javascript">';
		echo 'alert("Somthing went wrong")';
		echo '</script>';
}
header("Location: http://mezyapps.com/tbh/");

?>